-- 增加链接图标URL字段
ALTER TABLE on_links ADD iconurl TEXT(256);